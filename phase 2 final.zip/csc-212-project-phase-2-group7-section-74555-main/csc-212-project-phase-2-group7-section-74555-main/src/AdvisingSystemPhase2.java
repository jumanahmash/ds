public class AdvisingSystemPhase2 implements IAdvisingSystemPhase2 {
    private Map<Integer, IAdvisor> advisors;
    private Map<Integer, IStudent> students;
    private Map<Integer, ILocation> locations;
    private Map<Integer, IMeeting> meetings;
    private Map<Integer, IWorkshop> workshops;
    private Map<Integer, IEvent> events;
    private int nextEventId;

    public AdvisingSystemPhase2() {
        advisors = new BSTMap<Integer, IAdvisor>();
        students = new BSTMap<Integer, IStudent>();
        locations = new BSTMap<Integer, ILocation>();
        meetings = new BSTMap<Integer, IMeeting>();
        workshops = new BSTMap<Integer, IWorkshop>();
        events = new BSTMap<Integer, IEvent>();
        nextEventId = 1;
    }

    public Set<IAdvisor> getAdvisors() { return valuesAsSet(advisors); }
    public Set<IStudent> getStudents() { return valuesAsSet(students); }
    public Set<ILocation> getLocations() { return valuesAsSet(locations); }
    public Set<IMeeting> getMeetings() { return valuesAsSet(meetings); }
    public Set<IWorkshop> getWorkshops() { return valuesAsSet(workshops); }
    public Set<IEvent> getEvents() { return valuesAsSet(events); }

    private <T extends Comparable<? super T>> Set<T> valuesAsSet(Map<Integer, T> map) {
        Set<T> set = new BSTSet<T>();
        List<Integer> keys = map.getKeys();
        keys.findFirst();
        while (!keys.empty()) {
            set.insert(map.get(keys.retrieve()));
            if (keys.last()) break;
            keys.findNext();
        }
        return set;
    }

    public boolean addAdvisor(IAdvisor advisor) {
        if (advisor == null) return false;
        return advisors.insert(advisor.getId(), advisor);
    }

    public IAdvisor searchAdvisorById(int advisorId) { return advisors.get(advisorId); }

    public boolean addStudent(IStudent student) {
        if (student == null) return false;
        return students.insert(student.getId(), student);
    }

    public IStudent searchStudentById(int studentId) { return students.get(studentId); }

    public boolean deleteStudent(int studentId) {
        IStudent student = students.get(studentId);
        if (student == null) return false;

        List<Integer> eventIds = events.getKeys();
        eventIds.findFirst();
        while (!eventIds.empty()) {
            int id = eventIds.retrieve();
            IEvent event = events.get(id);
            if (event instanceof IMeeting && ((IMeeting) event).getStudentId() == studentId) {
                cancelMeeting(id);
            } else if (event instanceof IWorkshop) {
                IWorkshop w = (IWorkshop) event;
                if (w.getStudentIds().contains(studentId)) {
                    removeStudentFromWorkshopSilently(id, studentId);
                }
            }
            if (eventIds.last()) break;
            eventIds.findNext();
        }
        return students.remove(studentId);
    }

    public boolean addLocation(ILocation location) {
        if (location == null) return false;
        return locations.insert(location.getId(), location);
    }

    public ILocation searchLocationById(int locationId) { return locations.get(locationId); }

    public int scheduleMeeting(ITimeSlot timeSlot, int advisorId, int studentId) throws SchedulingException {
        IAdvisor advisor = advisors.get(advisorId);
        if (advisor == null) throw new SchedulingException(ScheduleFailureReason.ADVISOR_NOT_FOUND);
        IStudent student = students.get(studentId);
        if (student == null) throw new SchedulingException(ScheduleFailureReason.STUDENT_NOT_FOUND);
        if (advisor.getSchedule().conflicts(timeSlot)) throw new SchedulingException(ScheduleFailureReason.CONFLICT_ADVISOR);
        if (student.getSchedule().conflicts(timeSlot)) throw new SchedulingException(ScheduleFailureReason.CONFLICT_STUDENT);

        int id = nextEventId++;
        ILocation office = advisor.getOffice();
        IMeeting meeting = new Meeting(id, timeSlot, office, advisorId, studentId);
        meetings.insert(id, meeting);
        events.insert(id, meeting);
        advisor.getSchedule().add(id, timeSlot);
        student.getSchedule().add(id, timeSlot);
        return id;
    }

    public int scheduleWorkshop(String title, ITimeSlot timeSlot, int locationId, int[] advisorIds, int[] studentIds)
            throws SchedulingException {
        ILocation location = locations.get(locationId);
        if (location == null) throw new SchedulingException(ScheduleFailureReason.LOCATION_NOT_FOUND);
        if (!location.isReservable()) throw new SchedulingException(ScheduleFailureReason.LOCATION_NOT_RESERVABLE);
        if (location.getSchedule() != null && location.getSchedule().conflicts(timeSlot))
            throw new SchedulingException(ScheduleFailureReason.CONFLICT_LOCATION);

        int advisorCount = advisorIds == null ? 0 : advisorIds.length;
        int studentCount = studentIds == null ? 0 : studentIds.length;
        if (location.getCapacity() > 0 && advisorCount + studentCount > location.getCapacity())
            throw new SchedulingException(ScheduleFailureReason.CAPACITY_EXCEEDED);

        Set<Integer> advSet = new BSTSet<Integer>();
        Set<Integer> stuSet = new BSTSet<Integer>();
        if (advisorIds != null) {
            for (int id : advisorIds) {
                IAdvisor a = advisors.get(id);
                if (a == null) throw new SchedulingException(ScheduleFailureReason.ADVISOR_NOT_FOUND);
                if (a.getSchedule().conflicts(timeSlot)) throw new SchedulingException(ScheduleFailureReason.CONFLICT_ADVISOR);
                advSet.insert(id);
            }
        }
        if (studentIds != null) {
            for (int id : studentIds) {
                IStudent s = students.get(id);
                if (s == null) throw new SchedulingException(ScheduleFailureReason.STUDENT_NOT_FOUND);
                if (s.getSchedule().conflicts(timeSlot)) throw new SchedulingException(ScheduleFailureReason.CONFLICT_STUDENT);
                stuSet.insert(id);
            }
        }

        int id = nextEventId++;
        IWorkshop workshop = new Workshop(id, title, timeSlot, location, advSet, stuSet);
        workshops.insert(id, workshop);
        events.insert(id, workshop);
        addEventToPeopleSchedules(id, timeSlot, advSet, true);
        addEventToPeopleSchedules(id, timeSlot, stuSet, false);
        if (location.getSchedule() != null) location.getSchedule().add(id, timeSlot);
        return id;
    }

    private void addEventToPeopleSchedules(int eventId, ITimeSlot slot, Set<Integer> ids, boolean advisorType) {
        List<Integer> list = ids.getKeys();
        list.findFirst();
        while (!list.empty()) {
            int id = list.retrieve();
            if (advisorType) advisors.get(id).getSchedule().add(eventId, slot);
            else students.get(id).getSchedule().add(eventId, slot);
            if (list.last()) break;
            list.findNext();
        }
    }

    private void removeEventFromPeopleSchedules(int eventId, Set<Integer> ids, boolean advisorType) {
        List<Integer> list = ids.getKeys();
        list.findFirst();
        while (!list.empty()) {
            int id = list.retrieve();
            if (advisorType && advisors.get(id) != null) advisors.get(id).getSchedule().remove(eventId);
            if (!advisorType && students.get(id) != null) students.get(id).getSchedule().remove(eventId);
            if (list.last()) break;
            list.findNext();
        }
    }

    public boolean cancelMeeting(int meetingId) {
        IMeeting meeting = meetings.get(meetingId);
        if (meeting == null) return false;
        IAdvisor advisor = advisors.get(meeting.getAdvisorId());
        IStudent student = students.get(meeting.getStudentId());
        if (advisor != null) advisor.getSchedule().remove(meetingId);
        if (student != null) student.getSchedule().remove(meetingId);
        meetings.remove(meetingId);
        events.remove(meetingId);
        return true;
    }

    public boolean cancelWorkshop(int workshopId) {
        IWorkshop workshop = workshops.get(workshopId);
        if (workshop == null) return false;
        removeEventFromPeopleSchedules(workshopId, workshop.getAdvisorIds(), true);
        removeEventFromPeopleSchedules(workshopId, workshop.getStudentIds(), false);
        if (workshop.getLocation() != null && workshop.getLocation().getSchedule() != null)
            workshop.getLocation().getSchedule().remove(workshopId);
        workshops.remove(workshopId);
        events.remove(workshopId);
        return true;
    }

    public void addStudentToWorkshop(int workshopId, int studentId) throws SchedulingException {
        IWorkshop workshop = workshops.get(workshopId);
        if (workshop == null) throw new SchedulingException(ScheduleFailureReason.EVENT_NOT_FOUND);
        IStudent student = students.get(studentId);
        if (student == null) throw new SchedulingException(ScheduleFailureReason.STUDENT_NOT_FOUND);
        if (workshop.getStudentIds().contains(studentId)) return;
        if (student.getSchedule().conflicts(workshop.getTimeSlot())) throw new SchedulingException(ScheduleFailureReason.CONFLICT_STUDENT);
        if (workshop.getLocation().getCapacity() > 0 && workshop.getParticipantIds().size() + 1 > workshop.getLocation().getCapacity())
            throw new SchedulingException(ScheduleFailureReason.CAPACITY_EXCEEDED);
        ((Workshop) workshop).addStudentId(studentId);
        student.getSchedule().add(workshopId, workshop.getTimeSlot());
    }

    public void removeStudentFromWorkshop(int workshopId, int studentId) throws SchedulingException {
        IWorkshop workshop = workshops.get(workshopId);
        if (workshop == null) throw new SchedulingException(ScheduleFailureReason.EVENT_NOT_FOUND);
        if (students.get(studentId) == null) throw new SchedulingException(ScheduleFailureReason.STUDENT_NOT_FOUND);
        if (!workshop.getStudentIds().contains(studentId)) throw new SchedulingException(ScheduleFailureReason.STUDENT_NOT_FOUND);
        removeStudentFromWorkshopSilently(workshopId, studentId);
    }

    private void removeStudentFromWorkshopSilently(int workshopId, int studentId) {
        IWorkshop workshop = workshops.get(workshopId);
        if (workshop == null) return;
        IStudent student = students.get(studentId);
        if (student != null) student.getSchedule().remove(workshopId);
        ((Workshop) workshop).removeStudentId(studentId);
        if (workshop.getParticipantIds().empty()) cancelWorkshop(workshopId);
    }

    public void addAdvisorToWorkshop(int workshopId, int advisorId) throws SchedulingException {
        IWorkshop workshop = workshops.get(workshopId);
        if (workshop == null) throw new SchedulingException(ScheduleFailureReason.EVENT_NOT_FOUND);
        IAdvisor advisor = advisors.get(advisorId);
        if (advisor == null) throw new SchedulingException(ScheduleFailureReason.ADVISOR_NOT_FOUND);
        if (workshop.getAdvisorIds().contains(advisorId)) return;
        if (advisor.getSchedule().conflicts(workshop.getTimeSlot())) throw new SchedulingException(ScheduleFailureReason.CONFLICT_ADVISOR);
        if (workshop.getLocation().getCapacity() > 0 && workshop.getParticipantIds().size() + 1 > workshop.getLocation().getCapacity())
            throw new SchedulingException(ScheduleFailureReason.CAPACITY_EXCEEDED);
        ((Workshop) workshop).addAdvisorId(advisorId);
        advisor.getSchedule().add(workshopId, workshop.getTimeSlot());
    }

   public void removeAdvisorFromWorkshop(int workshopId, int advisorId) throws SchedulingException {
        IWorkshop workshop = workshops.get(workshopId);
        if (workshop == null) throw new SchedulingException(ScheduleFailureReason.EVENT_NOT_FOUND);
        
        IAdvisor advisor = advisors.get(advisorId);
        if (advisor == null) throw new SchedulingException(ScheduleFailureReason.ADVISOR_NOT_FOUND);
        
        if (!workshop.getAdvisorIds().contains(advisorId)) throw new SchedulingException(ScheduleFailureReason.ADVISOR_NOT_FOUND);
        
        ((Workshop) workshop).removeAdvisorId(advisorId);
        advisor.getSchedule().remove(workshopId);
        

        if (workshop.getParticipantIds().empty()) {
            cancelWorkshop(workshopId);
        }
    }
}

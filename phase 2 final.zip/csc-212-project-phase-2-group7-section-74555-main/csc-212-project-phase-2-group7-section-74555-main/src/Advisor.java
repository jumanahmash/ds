public class Advisor extends Person implements IAdvisor {
    private ILocation office;

    public Advisor(int id, String name, String email, ISchedule schedule, ILocation office) {
        super(id, name, email, schedule);
        this.office = office;
    }

    public ILocation getOffice() { return office; }

    public String toString() {
        return "Advisor{" + getId() + ", " + getName() + ", office=" + (office == null ? "none" : office.getName()) + "}";
    }
}

public class BSTMap<K extends Comparable<? super K>, T> implements Map<K, T> {
    private class Node {
        K key;
        T data;
        Node left, right;
        Node(K key, T data) { this.key = key; this.data = data; }
    }
    private Node root;
    private int size;

    @Override
    public int size() { return size; }

    @Override
    public boolean empty() { return size == 0; }

    @Override
    public void clear() { root = null; size = 0; }

    @Override
    public boolean insert(K key, T data) {
        if (key == null) return false; 
        if (root == null) {
            root = new Node(key, data);
            size++;
            return true;
        }
        Node p = root, parent = null;
        int cmp = 0;
        while (p != null) {
            parent = p;
            cmp = key.compareTo(p.key);
            if (cmp == 0) return false;
            p = cmp < 0 ? p.left : p.right;
        }
        if (cmp < 0) parent.left = new Node(key, data);
        else parent.right = new Node(key, data);
        size++;
        return true;
    }

    @Override
    public T get(K key) {
        if (key == null) return null; // FIX: null guard
        Node p = root;
        while (p != null) {
            int cmp = key.compareTo(p.key);
            if (cmp == 0) return p.data;
            p = cmp < 0 ? p.left : p.right;
        }
        return null;
    }

    @Override
    public boolean update(K key, T e) {
        if (key == null) return false; // FIX: null guard
        Node p = root;
        while (p != null) {
            int cmp = key.compareTo(p.key);
            if (cmp == 0) { p.data = e; return true; }
            p = cmp < 0 ? p.left : p.right;
        }
        return false;
    }

@Override
public boolean remove(K key) {
    if (key == null) return false;
    Node parent = null, current = root;

    // 1. البحث عن العقدة
    while (current != null) {
        int cmp = key.compareTo(current.key);
        if (cmp == 0) break;
        parent = current;
        current = cmp < 0 ? current.left : current.right;
    }

    if (current == null) return false; // العقدة غير موجودة

    // 2. حالة العقدة بطفلين: نجد البديل (Successor)
    if (current.left != null && current.right != null) {
        Node successorParent = current;
        Node successor = current.right;

        while (successor.left != null) {
            successorParent = successor;
            successor = successor.left;
        }

        // نسخ بيانات البديل للعقدة الحالية
        current.key = successor.key;
        current.data = successor.data;

        // نقل المراجع لحذف عقدة البديل الأصلية
        parent = successorParent;
        current = successor;
    }

    // 3. حذف العقدة (سواء كانت الأصلية أو البديل)
    // في هذه المرحلة، العقدة current مضمون أنها تملك طفلاً واحداً أو لا تملك
    Node child = (current.left != null) ? current.left : current.right;

    if (parent == null) {
        root = child; // حذف الجذر
    } else if (parent.left == current) {
        parent.left = child;
    } else {
        parent.right = child;
    }

    size--;
    return true;
}
    @Override
    public int nbKeyComp(K key) {
        int c = 0;
        Node p = root;
        while (p != null) {
            c++;
            int cmp = key.compareTo(p.key);
            if (cmp == 0) return c;
            p = cmp < 0 ? p.left : p.right;
        }
        return c;
    }

    @Override
    public List<K> getKeys() {
        LinkedList<K> list = new LinkedList<K>();
        if (root == null) return list;
        class StackNode {
            Node treeNode; StackNode next;
            StackNode(Node n, StackNode nx) { treeNode = n; next = nx; }
        }
        StackNode top = null;
        Node current = root;
        while (current != null || top != null) {
            while (current != null) {
                top = new StackNode(current, top);
                current = current.left;
            }
            current = top.treeNode;
            top = top.next;
            list.insert(current.key); 
            current = current.right;
        }
        return list;
    }

    @Override
    public String toString() { return getKeys().toString(); }
}

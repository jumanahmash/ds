public class BSTSet<K extends Comparable<? super K>> implements Set<K> {
    private class Node {
        K key;
        Node left, right;
        Node(K key) { this.key = key; }
    }
    private Node root;
    private int size;

    @Override
    public int size() { return size; }

    @Override
    public boolean empty() { return size == 0; }

    @Override
    public void clear() { root = null; size = 0; }

    @Override
    public boolean contains(K k) {
        if (k == null) return false; // FIX: null guard
        Node p = root;
        while (p != null) {
            int cmp = k.compareTo(p.key);
            if (cmp == 0) return true;
            p = cmp < 0 ? p.left : p.right;
        }
        return false;
    }

    @Override
    public int nbKeyComp(K k) {
        int c = 0;
        Node p = root;
        while (p != null) {
            c++;
            int cmp = k.compareTo(p.key);
            if (cmp == 0) return c;
            p = cmp < 0 ? p.left : p.right;
        }
        return c;
    }

    @Override
    public boolean insert(K k) {
        if (k == null) return false; // FIX: null guard
        if (root == null) {
            root = new Node(k);
            size++;
            return true;
        }
        Node p = root, parent = null;
        int cmp = 0;
        while (p != null) {
            parent = p;
            cmp = k.compareTo(p.key);
            if (cmp == 0) return false;
            p = cmp < 0 ? p.left : p.right;
        }
        if (cmp < 0) parent.left = new Node(k);
        else parent.right = new Node(k);
        size++;
        return true;
    }
@Override
public boolean remove(K key) {
    if (key == null) return false;
    Node parent = null, current = root;

    while (current != null) {
        int cmp = key.compareTo(current.key);
        if (cmp == 0) break;
        parent = current;
        current = cmp < 0 ? current.left : current.right;
    }

    if (current == null) return false;

    if (current.left != null && current.right != null) {
        Node successorParent = current;
        Node successor = current.right;

        while (successor.left != null) {
            successorParent = successor;
            successor = successor.left;
        }

        // في الـ Set نقوم بنسخ المفتاح (key) فقط ولا يوجد data
        current.key = successor.key;

        parent = successorParent;
        current = successor;
    }

    Node child = (current.left != null) ? current.left : current.right;

    if (parent == null) {
        root = child;
    } else if (parent.left == current) {
        parent.left = child;
    } else {
        parent.right = child;
    }

    size--;
    return true;
}

    @Override
    public List<K> getKeys() {
        LinkedList<K> list = new LinkedList<K>();
        if (root == null) return list;
        class StackNode {
            Node treeNode;
            StackNode next;
            StackNode(Node n, StackNode nx) { treeNode = n; next = nx; }
        }
        StackNode top = null;
        Node current = root;
        while (current != null || top != null) {
            while (current != null) {
                top = new StackNode(current, top);
                current = current.left;
            }
            current = top.treeNode;
            top = top.next;
            list.insert(current.key);
            current = current.right;
        }
        return list;
    }

    @Override
    public String toString() { return getKeys().toString(); }
}

public class DateTime implements IDateTime {
    private int year, month, day, hour, minute;

    public DateTime(int year, int month, int day, int hour, int minute) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("month must be 1..12");
        }

        if (day < 1 || day > 31) {
            throw new IllegalArgumentException("day must be 1..31");
        }

        if (minute < 0 || minute > 59) {
            throw new IllegalArgumentException("minute must be 0..59");
        }

        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int compareTo(IDateTime other) {
        if (year != other.getYear()) {
            return year - other.getYear();
        }

        if (month != other.getMonth()) {
            return month - other.getMonth();
        }

        if (day != other.getDay()) {
            return day - other.getDay();
        }

        if (hour != other.getHour()) {
            return hour - other.getHour();
        }

        return minute - other.getMinute();
    }

    public String format() {
        return String.format("%02d/%02d/%04d %02d:%02d",
                month, day, year, hour, minute);
    }

    public String toString() {
        return format();
    }
}

public class LinkedList<T> implements List<T> {
    private static class Node<T> {
        T data;
        Node<T> next;
        Node(T data) { this.data = data; }
    }

    private Node<T> head;
    private Node<T> current;
    private int size;

    public int size() { return size; }

    @Override
    public boolean empty() { return head == null; }

    @Override
    public boolean last() { return current != null && current.next == null; }

    @Override
    public boolean full() { return false; }

    @Override
    public void findFirst() { current = head; }

    @Override
    public void findNext() {
        if (current != null) current = current.next;
    }

    @Override
    public T retrieve() { return current == null ? null : current.data; }

    @Override
    public void update(T val) {
        if (current != null) current.data = val;
    }

    @Override
    public void insert(T val) {
        Node<T> node = new Node<T>(val);
        if (head == null) {
            head = current = node;
        } else if (current == null) {
            node.next = head;
            head = current = node;
        } else {
            node.next = current.next;
            current.next = node;
            current = node;
        }
        size++;
    }

    public void append(T val) {
        Node<T> node = new Node<T>(val);
        if (head == null) {
            head = current = node;
        } else {
            Node<T> p = head;
            while (p.next != null) p = p.next;
            p.next = node;
            current = node;
        }
        size++;
    }

    @Override
    public void remove() {
        if (current == null) return;
        if (current == head) {
            head = head.next;
            current = head;
        } else {
            Node<T> prev = head;
            while (prev != null && prev.next != current) prev = prev.next;
            if (prev != null) {
                prev.next = current.next;
                current = prev.next != null ? prev.next : prev;
            }
        }
        size--;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        Node<T> p = head;
        while (p != null) {
            sb.append(p.data);
            if (p.next != null) sb.append(", ");
            p = p.next;
        }
        sb.append("]");
        return sb.toString();
    }
}

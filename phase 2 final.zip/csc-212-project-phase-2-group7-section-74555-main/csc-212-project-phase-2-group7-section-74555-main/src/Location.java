public class Location implements ILocation {
    private int id;
    private String name;
    private boolean reservable;
    private boolean online;
    private int capacity;
    private ISchedule schedule;

    public Location(int id, String name, boolean reservable, boolean online, int capacity, ISchedule schedule) {
        this.id = id;
        this.name = name;
        this.reservable = reservable;
        this.online = online;
        if (online) this.capacity = -1;
        else if (!reservable) this.capacity = 1;
        else this.capacity = capacity;
        this.schedule = reservable ? schedule : null;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public boolean isReservable() { return reservable; }
    public ISchedule getSchedule() { return schedule; }
    public int getCapacity() { return capacity; }
    public boolean isOnline() { return online; }
    public int compareTo(ILocation other) { return this.id - other.getId(); }

    public String toString() {
        return "Location{" + id + ", " + name + ", reservable=" + reservable + ", online=" + online + ", capacity=" + capacity + "}";
    }
}

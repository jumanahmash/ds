public class Meeting extends Event implements IMeeting {
    private int advisorId;
    private int studentId;

    public Meeting(int id, ITimeSlot timeSlot, ILocation location, int advisorId, int studentId) {
        super(id, timeSlot, location, buildParticipants(advisorId, studentId));
        this.advisorId = advisorId;
        this.studentId = studentId;
    }

    private static Set<Integer> buildParticipants(int advisorId, int studentId) {
        Set<Integer> s = new BSTSet<Integer>();
        s.insert(advisorId);
        s.insert(studentId);
        return s;
    }

    public int getAdvisorId() { return advisorId; }
    public int getStudentId() { return studentId; }

    public String toString() {
        return "Meeting{" + getId() + ", advisor=" + advisorId + ", student=" + studentId + ", " + getTimeSlot() + "}";
    }
}

public class Schedule implements ISchedule {
    private Map<Integer, ITimeSlot> byId;
    private Map<ITimeSlot, Integer> byTime;

    public Schedule() {
        byId = new BSTMap<Integer, ITimeSlot>();
        byTime = new BSTMap<ITimeSlot, Integer>();
    }

    public int size() {
        return byId.size();
    }

    public boolean empty() {
        return byId.empty();
    }

    public void clear() {
        byId.clear();
        byTime.clear();
    }

    public boolean add(int eventId, ITimeSlot timeSlot) {
        if (timeSlot == null) {
            return false;
        }

        if (byId.get(eventId) != null) {
            return false;
        }

        if (conflicts(timeSlot)) {
            return false;
        }

        boolean addedById = byId.insert(eventId, timeSlot);
        boolean addedByTime = byTime.insert(timeSlot, eventId);

        if (!addedById || !addedByTime) {
            if (addedById) {
                byId.remove(eventId);
            }

            if (addedByTime) {
                byTime.remove(timeSlot);
            }

            return false;
        }

        return true;
    }

    public boolean remove(int eventId) {
        ITimeSlot timeSlot = byId.get(eventId);

        if (timeSlot == null) {
            return false;
        }

        byId.remove(eventId);
        byTime.remove(timeSlot);

        return true;
    }

    public boolean contains(int eventId) {
        return byId.get(eventId) != null;
    }

    public boolean conflicts(ITimeSlot timeSlot) {
        if (timeSlot == null) {
            return false;
        }

        return byTime.get(timeSlot) != null;
    }

    public Set<Integer> getEventIds() {
        Set<Integer> result = new BSTSet<Integer>();
        List<Integer> keys = byId.getKeys();

        if (keys == null || keys.empty()) {
            return result;
        }

        keys.findFirst();

        while (true) {
            Integer id = keys.retrieve();

            if (id != null) {
                result.insert(id);
            }

            if (keys.last()) {
                break;
            }

            keys.findNext();
        }

        return result;
    }

    public Map<ITimeSlot, Integer> getEvents() {
        return byTime;
    }

    public String toString() {
        return byTime.toString();
    }
}

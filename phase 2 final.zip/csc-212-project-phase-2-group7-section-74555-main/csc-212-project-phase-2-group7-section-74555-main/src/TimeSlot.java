public class TimeSlot implements ITimeSlot {
    private IDateTime start;
    private IDateTime end;

    public TimeSlot(IDateTime start, IDateTime end) {
        if (start == null || end == null) throw new IllegalArgumentException("start and end are required");
        if (start.compareTo(end) > 0) throw new IllegalArgumentException("start must be before end");
        this.start = start;
        this.end = end;
    }

    public IDateTime getStart() { return start; }
    public IDateTime getEnd() { return end; }

    public int compareTo(ITimeSlot other) {
        if (this.end.compareTo(other.getStart()) <= 0) return -1;
        if (this.start.compareTo(other.getEnd()) >= 0) return 1;
        return 0;
    }

    public String toString() { return start.format() + " - " + end.format(); }
}

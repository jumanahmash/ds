public class Workshop extends Event implements IWorkshop {
    private String title;
    private Set<Integer> advisorIds;
    private Set<Integer> studentIds;

    public Workshop(int id, String title, ITimeSlot timeSlot, ILocation location, Set<Integer> advisorIds, Set<Integer> studentIds) {
        super(id, timeSlot, location, merge(advisorIds, studentIds));
        this.title = title;
        
        // 1. إجراء نسخ عميق (Deep Copy) لمجموعة المرشدين
        this.advisorIds = new BSTSet<Integer>();
        copyInto(advisorIds, this.advisorIds);
        
        // 2. إجراء نسخ عميق (Deep Copy) لمجموعة الطلاب
        this.studentIds = new BSTSet<Integer>();
        copyInto(studentIds, this.studentIds);
    }

    private static Set<Integer> merge(Set<Integer> advisors, Set<Integer> students) {
        Set<Integer> all = new BSTSet<Integer>();
        copyInto(advisors, all);
        copyInto(students, all);
        return all;
    }

    private static void copyInto(Set<Integer> from, Set<Integer> to) {
        if (from == null || from.empty()) return;
        List<Integer> keys = from.getKeys();
        keys.findFirst();
        while (!keys.empty()) {
            to.insert(keys.retrieve());
            if (keys.last()) break;
            keys.findNext();
        }
    }

    public String getTitle() { return title; }
    public Set<Integer> getAdvisorIds() { return advisorIds; }
    public Set<Integer> getStudentIds() { return studentIds; }

    public void addStudentId(int id) { studentIds.insert(id); getParticipantIds().insert(id); }
    public void removeStudentId(int id) { studentIds.remove(id); getParticipantIds().remove(id); }
    public void addAdvisorId(int id) { advisorIds.insert(id); getParticipantIds().insert(id); }
    public void removeAdvisorId(int id) { advisorIds.remove(id); getParticipantIds().remove(id); }

    public String toString() {
        return "Workshop{" + getId() + ", " + title + ", advisors=" + advisorIds + ", students=" + studentIds + ", " + getTimeSlot() + "}";
    }
}

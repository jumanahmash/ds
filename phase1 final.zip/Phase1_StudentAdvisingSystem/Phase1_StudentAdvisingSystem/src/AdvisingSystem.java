import java.io.BufferedReader;
import java.io.FileReader;

public class AdvisingSystem implements IAdvisingSystem {
    private StudentList studentList = new StudentList();
    private EventList eventList = new EventList();

    public boolean loadStudentsFromCSV(String studentsFilePath) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(studentsFilePath));
            String line = br.readLine(); // header
            while ((line = br.readLine()) != null) {
                String[] c = splitCSV(line);
                if (c.length >= 6) {
                    int id = Integer.parseInt(c[0].trim());
                    int year = Integer.parseInt(c[4].trim());
                    addStudent(new Student(c[1].trim(), id, c[2].trim(), c[3].trim(), year, c[5].trim()));
                }
            }
            br.close();
            return true;
        } catch (Exception e) {
            System.out.println("Could not load students: " + e.getMessage());
            return false;
        }
    }

    public boolean loadEventsFromCSV(String eventsFilePath) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(eventsFilePath));
            String line = br.readLine(); // header
            int currentWorkshopId = -1;
            String workshopTitle = "", workshopLocation = "";
            IDateTime workshopStart = null, workshopEnd = null;
            int[] ids = new int[200];
            int count = 0;
            int skipped = 0;

            while ((line = br.readLine()) != null) {
                String[] c = splitCSV(line);
                if (c.length < 7) continue;
                int eventId = Integer.parseInt(c[0].trim());
                String title = c[1].trim();
                String type = c[2].trim();
                int studentId = Integer.parseInt(c[3].trim());
                IDateTime start = DateTime.parse(c[4].trim());
                IDateTime end = DateTime.parse(c[5].trim());
                String location = c[6].trim();

                if (type.equalsIgnoreCase("Meeting")) {
                    if (currentWorkshopId != -1) {
                        if (!scheduleWorkshopWithId(currentWorkshopId, workshopTitle, workshopStart, workshopEnd, workshopLocation, ids, count)) skipped++;
                        currentWorkshopId = -1; count = 0;
                    }
                    if (!scheduleMeetingWithId(eventId, title, start, end, location, studentId)) skipped++;
                } else { // Workshop rows are repeated by participant.
                    if (currentWorkshopId != -1 && eventId != currentWorkshopId) {
                        if (!scheduleWorkshopWithId(currentWorkshopId, workshopTitle, workshopStart, workshopEnd, workshopLocation, ids, count)) skipped++;
                        count = 0;
                    }
                    currentWorkshopId = eventId;
                    workshopTitle = title;
                    workshopStart = start;
                    workshopEnd = end;
                    workshopLocation = location;
                    if (count < ids.length) ids[count++] = studentId;
                }
            }
            if (currentWorkshopId != -1) {
                if (!scheduleWorkshopWithId(currentWorkshopId, workshopTitle, workshopStart, workshopEnd, workshopLocation, ids, count)) skipped++;
            }
            br.close();
            if (skipped > 0) System.out.println("Skipped " + skipped + " event(s) because of missing students or time conflicts.");
            return true;
        } catch (Exception e) {
            System.out.println("Could not load events: " + e.getMessage());
            return false;
        }
    }

    private String[] splitCSV(String line) {
        // Dataset has simple comma-separated fields with no quoted commas.
        return line.split(",", -1);
    }

    public boolean addStudent(IStudent student) {
        if (student == null || student.getStudentId() <= 0) return false;
        return studentList.add(student);
    }

    public IStudent searchStudentById(int studentId) { return studentList.findById(studentId); }
    public IStudent searchStudentByEmail(String email) { return studentList.findByEmail(email); }

    public void printStudentsByMajor(String major) { printStudentList(studentList.findByMajor(major)); }
    public void printStudentsByYearLevel(int yearLevel) { printStudentList(studentList.findByYearLevel(yearLevel)); }
    public void printStudentsByName(String fullName) { printStudentList(studentList.findByName(fullName)); }
    public void printStudentsByPartialName(String partialName) { printStudentList(studentList.findByNameContains(partialName)); }
    public void printAllStudents() { printStudentList(studentList.getAll()); }

    private void printStudentList(LinkedList<IStudent> list) {
        if (list == null || list.isEmpty()) { System.out.println("No students found."); return; }
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
            System.out.println("--------------------");
        }
    }

    public boolean deleteStudent(int studentId) {
        IStudent student = studentList.findById(studentId);
        if (student == null) return false;

        LinkedList<IEvent> events = eventList.getAllAlphabetically();
        for (int i = 0; i < events.size(); i++) {
            IEvent event = events.get(i);
            if (event instanceof IMeeting && event.hasStudent(studentId)) {
                removeEventFromStudents(event);
                eventList.removeEventById(event.getEventId());
                i--;
            } else if (event instanceof IWorkshop && event.hasStudent(studentId)) {
                ((IWorkshop) event).removeParticipantById(studentId);
                removeFromStudentSchedule(student, event.getEventId());
                if (((IWorkshop) event).isEmpty()) {
                    removeEventFromStudents(event);
                    eventList.removeEventById(event.getEventId());
                    i--;
                }
            }
        }
        return studentList.deleteById(studentId);
    }

    public boolean scheduleMeeting(String title, IDateTime startDateTime, IDateTime endDateTime, String location, int studentId) {
        return scheduleMeetingWithId(-1, title, startDateTime, endDateTime, location, studentId);
    }

    private boolean scheduleMeetingWithId(int eventId, String title, IDateTime startDateTime, IDateTime endDateTime, String location, int studentId) {
        IStudent student = studentList.findById(studentId);
        if (student == null || !validTime(startDateTime, endDateTime) || hasConflict(student, startDateTime, endDateTime)) return false;
        Meeting meeting = eventId > 0 ? new Meeting(eventId, title, startDateTime, endDateTime, location, student)
                                      : new Meeting(title, startDateTime, endDateTime, location, student);
        eventList.addEvent(meeting);
        student.getSchedule().addLast(meeting);
        return true;
    }

    public boolean scheduleWorkshop(String title, IDateTime startDateTime, IDateTime endDateTime, String location, int[] studentIds) {
        return scheduleWorkshopWithId(-1, title, startDateTime, endDateTime, location, studentIds, studentIds.length);
    }

    private boolean scheduleWorkshopWithId(int eventId, String title, IDateTime startDateTime, IDateTime endDateTime, String location, int[] studentIds, int count) {
        if (!validTime(startDateTime, endDateTime) || count <= 0) return false;
        for (int i = 0; i < count; i++) {
            IStudent student = studentList.findById(studentIds[i]);
            if (student == null || hasConflict(student, startDateTime, endDateTime)) return false;
        }
        Workshop workshop = eventId > 0 ? new Workshop(eventId, title, startDateTime, endDateTime, location)
                                        : new Workshop(title, startDateTime, endDateTime, location);
        for (int i = 0; i < count; i++) {
            IStudent student = studentList.findById(studentIds[i]);
            if (workshop.addParticipant(student)) student.getSchedule().addLast(workshop);
        }
        eventList.addEvent(workshop);
        return true;
    }

    private boolean validTime(IDateTime start, IDateTime end) {
        return start != null && end != null && start.compareTo(end) < 0;
    }

    private boolean hasConflict(IStudent student, IDateTime start, IDateTime end) {
        LinkedList<IEvent> schedule = student.getSchedule();
        for (int i = 0; i < schedule.size(); i++) {
            IEvent e = schedule.get(i);
            if (overlaps(start, end, e.getStartDateTime(), e.getEndDateTime())) return true;
        }
        return false;
    }

    private boolean overlaps(IDateTime s1, IDateTime e1, IDateTime s2, IDateTime e2) {
        return s1.compareTo(e2) < 0 && s2.compareTo(e1) < 0;
    }

    private void removeEventFromStudents(IEvent event) {
        if (event instanceof IMeeting) {
            IStudent s = ((IMeeting) event).getStudent();
            if (s != null) removeFromStudentSchedule(s, event.getEventId());
        } else if (event instanceof IWorkshop) {
            LinkedList<IStudent> parts = ((IWorkshop) event).getParticipants();
            for (int i = 0; i < parts.size(); i++) removeFromStudentSchedule(parts.get(i), event.getEventId());
        }
    }

    private void removeFromStudentSchedule(IStudent student, int eventId) {
        LinkedList<IEvent> schedule = student.getSchedule();
        for (int i = 0; i < schedule.size(); i++) {
            if (schedule.get(i).getEventId() == eventId) { schedule.removeAt(i); return; }
        }
    }

    public void printEventDetailsByTitle(String title) { printEventList(eventList.findByTitle(title)); }
    public void printEventDetailsByStudentName(String studentName) { printEventList(eventList.findByStudentName(studentName)); }

    public void printWorkshopStudents(String workshopTitle) {
        LinkedList<IEvent> events = eventList.findByTitle(workshopTitle);
        boolean found = false;
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i) instanceof IWorkshop) {
                found = true;
                System.out.println("Workshop: " + events.get(i).getTitle());
                LinkedList<IStudent> p = ((IWorkshop) events.get(i)).getParticipants();
                for (int j = 0; j < p.size(); j++) System.out.println(p.get(j).getName() + " - " + p.get(j).getStudentId());
            }
        }
        if (!found) System.out.println("Workshop not found.");
    }

    public void printAllEventsAlphabetically() { printEventList(eventList.getAllAlphabetically()); }

    private void printEventList(LinkedList<IEvent> list) {
        if (list == null || list.isEmpty()) { System.out.println("No events found."); return; }
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
            System.out.println("--------------------");
        }
    }
    public boolean scheduleWorkshopByNames(String title, IDateTime start, IDateTime end,
                                       String location, String namesLine) {

    String[] names = namesLine.split(",");
    int[] ids = new int[names.length];

    for (int i = 0; i < names.length; i++) {
        LinkedList<IStudent> found = studentList.findByName(names[i].trim());

        if (found == null || found.isEmpty()) {
            System.out.println("Student not found: " + names[i].trim());
            return false;
        }

        ids[i] = found.get(0).getStudentId();
    }

    return scheduleWorkshop(title, start, end, location, ids);
}

    public int studentCount() { return studentList.size(); }
    public int eventCount() { return eventList.size(); }
}

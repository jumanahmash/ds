public class DateTime implements IDateTime {
    private int year, month, day, hour, minute;

    public DateTime(int month, int day, int year, int hour, int minute) {
        this.month = month;
        this.day = day;
        this.year = year;
        this.hour = hour;
        this.minute = minute;
    }

    public static DateTime parse(String text) {
        // Expected format: M/D/YYYY HH:MM or MM/DD/YYYY HH:MM
        String[] parts = text.trim().split(" ");
        String[] date = parts[0].split("/");
        String[] time = parts[1].split(":");
        return new DateTime(
            Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2]),
            Integer.parseInt(time[0]), Integer.parseInt(time[1])
        );
    }

    public int getYear() { return year; }
    public int getMonth() { return month; }
    public int getDay() { return day; }
    public int getHour() { return hour; }
    public int getMinute() { return minute; }

    public String format() {
        return two(month) + "/" + two(day) + "/" + year + " " + two(hour) + ":" + two(minute);
    }

    private String two(int n) { return n < 10 ? "0" + n : "" + n; }

    private long asMinutes() {
        // Simple comparable value sufficient for ordering project dates.
        return (((long)year * 12 + month) * 31 + day) * 24 * 60 + hour * 60 + minute;
    }

    public int compareTo(IDateTime other) {
        long a = asMinutes();
        long b = (((long)other.getYear() * 12 + other.getMonth()) * 31 + other.getDay()) * 24 * 60
                + other.getHour() * 60 + other.getMinute();
        if (a < b) return -1;
        if (a > b) return 1;
        return 0;
    }
}

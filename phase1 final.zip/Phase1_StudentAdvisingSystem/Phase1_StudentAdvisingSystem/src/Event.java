public abstract class Event implements IEvent {
    private static int nextId = 1;
    protected int eventId;
    protected String title;
    protected final IDateTime startDateTime;
    protected final IDateTime endDateTime;
    protected String location;

    public Event(String title, IDateTime startDateTime, IDateTime endDateTime, String location) {
        this(nextId++, title, startDateTime, endDateTime, location);
    }

    public Event(int eventId, String title, IDateTime startDateTime, IDateTime endDateTime, String location) {
        this.eventId = eventId;
        if (eventId >= nextId) nextId = eventId + 1;
        this.title = title;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.location = location;
    }

    public int getEventId() { return eventId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public IDateTime getStartDateTime() { return startDateTime; }
    public IDateTime getEndDateTime() { return endDateTime; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public int compareTo(IEvent other) {
        return this.title.compareToIgnoreCase(other.getTitle());
    }

    public String baseString() {
        return "Event ID: " + eventId +
               "\nTitle: " + title +
               "\nStart: " + startDateTime.format() +
               "\nEnd: " + endDateTime.format() +
               "\nLocation: " + location;
    }
}

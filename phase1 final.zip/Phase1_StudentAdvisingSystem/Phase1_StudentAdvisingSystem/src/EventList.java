public class EventList implements IEventList {
    private LinkedList<IEvent> events = new LinkedList<IEvent>();

    public boolean addEvent(IEvent event) {
        if (event == null) return false;
        int index = 0;
        while (index < events.size() && events.get(index).compareTo(event) <= 0) index++;
        events.insertAt(index, event);
        return true;
    }

    public boolean removeEventById(int eventId) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).getEventId() == eventId) return events.removeAt(i);
        }
        return false;
    }

    public LinkedList<IEvent> getAllAlphabetically() { return events; }

    public IEvent findById(int eventId) {
        for (int i = 0; i < events.size(); i++)
            if (events.get(i).getEventId() == eventId) return events.get(i);
        return null;
    }

    public LinkedList<IEvent> findByTitle(String title) {
        LinkedList<IEvent> result = new LinkedList<IEvent>();
        for (int i = 0; i < events.size(); i++)
            if (events.get(i).getTitle().equalsIgnoreCase(title)) result.addLast(events.get(i));
        return result;
    }

    public LinkedList<IEvent> findByStudentName(String studentFullName) {
        LinkedList<IEvent> result = new LinkedList<IEvent>();
        for (int i = 0; i < events.size(); i++) {
            IEvent event = events.get(i);
            if (event instanceof IMeeting) {
                IStudent s = ((IMeeting) event).getStudent();
                if (s != null && s.getName().equalsIgnoreCase(studentFullName)) result.addLast(event);
            } else if (event instanceof IWorkshop) {
                LinkedList<IStudent> parts = ((IWorkshop) event).getParticipants();
                for (int j = 0; j < parts.size(); j++) {
                    if (parts.get(j).getName().equalsIgnoreCase(studentFullName)) {
                        result.addLast(event);
                        break;
                    }
                }
            }
        }
        return result;
    }

    public int size() { return events.size(); }
}

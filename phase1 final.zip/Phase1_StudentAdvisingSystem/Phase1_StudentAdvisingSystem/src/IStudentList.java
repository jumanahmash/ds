public interface IStudentList {
    boolean add(IStudent student);
    IStudent findById(int studentId);
    LinkedList<IStudent> findByName(String fullName);
    LinkedList<IStudent> findByNameContains(String partialName);
    IStudent findByEmail(String email);
    LinkedList<IStudent> findByMajor(String major);
    LinkedList<IStudent> findByYearLevel(int yearLevel);
    LinkedList<IStudent> getAll();
    boolean deleteById(int studentId);
    int size();
}

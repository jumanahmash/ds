public interface IWorkshop extends IEvent {
    LinkedList<IStudent> getParticipants();
    boolean addParticipant(IStudent student);
    boolean removeParticipantById(int studentId);
    boolean isEmpty();
}

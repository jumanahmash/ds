/** Custom singly linked list. java.util collections are not used. */
public class LinkedList<T> {
    private static class Node<T> {
        T data;
        Node<T> next;
        Node(T data) { this.data = data; }
    }

    private Node<T> head;
    private int size;

    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }

    public void addLast(T item) {
        Node<T> newNode = new Node<T>(item);
        if (head == null) head = newNode;
        else {
            Node<T> current = head;
            while (current.next != null) current = current.next;
            current.next = newNode;
        }
        size++;
    }

    public void addFirst(T item) {
        Node<T> newNode = new Node<T>(item);
        newNode.next = head;
        head = newNode;
        size++;
    }

    public void insertAt(int index, T item) {
        if (index <= 0) { addFirst(item); return; }
        if (index >= size) { addLast(item); return; }
        Node<T> current = head;
        for (int i = 0; i < index - 1; i++) current = current.next;
        Node<T> newNode = new Node<T>(item);
        newNode.next = current.next;
        current.next = newNode;
        size++;
    }

    public T get(int index) {
        if (index < 0 || index >= size) return null;
        Node<T> current = head;
        for (int i = 0; i < index; i++) current = current.next;
        return current.data;
    }

    public boolean removeAt(int index) {
        if (index < 0 || index >= size) return false;
        if (index == 0) head = head.next;
        else {
            Node<T> current = head;
            for (int i = 0; i < index - 1; i++) current = current.next;
            current.next = current.next.next;
        }
        size--;
        return true;
    }

    public String toString() {
        String result = "";
        Node<T> current = head;
        while (current != null) {
            result += current.data;
            if (current.next != null) result += "\n";
            current = current.next;
        }
        return result;
    }
}

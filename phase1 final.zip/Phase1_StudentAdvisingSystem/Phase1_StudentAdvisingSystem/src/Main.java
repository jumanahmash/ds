import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AdvisingSystem system = new AdvisingSystem();
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the Student Advising System!");

        int choice;
        do {
            printMenu();
            choice = readInt(input, "Enter your choice: ");
            input.nextLine();

            switch (choice) {
                case 1: addStudent(system, input); break;
                case 2: searchStudent(system, input); break;
                case 3: deleteStudent(system, input); break;
                case 4: scheduleEvent(system, input); break;
                case 5: printEventDetails(system, input); break;
                case 6: printStudents(system, input); break;
                case 7: system.printAllEventsAlphabetically(); break;
                case 8: loadCSV(system, input); break;
                case 9: system.printAllStudents(); break;
                case 0: System.out.println("Goodbye!"); break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    private static void printMenu() {
        System.out.println("\nPlease choose an option:");
        System.out.println("1. Add a student");
        System.out.println("2. Search for a student");
        System.out.println("3. Delete a student");
        System.out.println("4. Schedule a meeting/workshop");
        System.out.println("5. Print meeting/workshop details");
        System.out.println("6. Print students by name/major/year");
        System.out.println("7. Print all meetings/workshops alphabetically");
        System.out.println("8. Load students/events from CSV");
        System.out.println("9. Print all students");
        System.out.println("0. Exit");
    }

    private static int readInt(Scanner input, String message) {
        System.out.print(message);
        while (!input.hasNextInt()) {
            input.next();
            System.out.print(message);
        }
        return input.nextInt();
    }

    private static void addStudent(AdvisingSystem system, Scanner input) {
        System.out.print("Enter the student's name: ");
        String name = input.nextLine();
        int id = readInt(input, "Enter the student's ID: "); input.nextLine();
        System.out.print("Enter the student's email address: ");
        String email = input.nextLine();
        System.out.print("Enter the student's major: ");
        String major = input.nextLine();
        int year = readInt(input, "Enter the student's year level: "); input.nextLine();
        System.out.print("Enter any notes for the student: ");
        String notes = input.nextLine();
        boolean added = system.addStudent(new Student(name, id, email, major, year, notes));
        System.out.println(added ? "Student added successfully!" : "Student could not be added.");
    }

private static void searchStudent(AdvisingSystem system, Scanner input) {
    System.out.println("Enter search criteria:");
    System.out.println("1. Name");
    System.out.println("2. Student ID");
    
    int choice = readInt(input, "Enter your choice: ");   
    input.nextLine(); // Clear the buffer after reading the integer

    if (choice == 1) {
        System.out.print("Enter student name: ");
        String name = input.nextLine();
        // Returns all students matching the name (likely a list or printed directly)
        system.printStudentsByName(name);
        
    } else if (choice == 2) {
        System.out.print("Enter student ID: ");
        if (input.hasNextInt()) {
            int id = input.nextInt();
            input.nextLine(); // Clear buffer

            IStudent student = system.searchStudentById(id);
            if (student != null) {
                System.out.println("Student found: " + student);
            } else {
                System.out.println("No student found with ID: " + id);
            }
        } else {
            System.out.println("Invalid ID format. Please enter a number.");
            input.nextLine(); // Clear invalid input
        }
    } else {
        System.out.println("Invalid selection. Please choose 1 or 2.");
    }
}

    private static void deleteStudent(AdvisingSystem system, Scanner input) {
        int id = readInt(input, "Enter student ID to delete: "); input.nextLine();
        System.out.println(system.deleteStudent(id) ? "Student deleted successfully." : "Student not found.");
    }
private static void scheduleEvent(AdvisingSystem system, Scanner input) {
    System.out.println("Enter type:");
    System.out.println("1. Workshop");
    System.out.println("2. Meeting");

    int type = readInt(input, "Enter your choice: ");
    input.nextLine();

    if (type == 1) {
        System.out.print("Enter workshop title: ");
        String title = input.nextLine();

        System.out.print("Enter student names separated by a comma: ");
        String namesLine = input.nextLine();

        System.out.print("Enter workshop date and time (MM/DD/YYYY HH:MM): ");
        IDateTime start = DateTime.parse(input.nextLine());

        IDateTime end = addOneHour(start);

        System.out.print("Enter workshop location: ");
        String location = input.nextLine();

        boolean ok = system.scheduleWorkshopByNames(title, start, end, location, namesLine);

        System.out.println(ok ? "Workshop scheduled successfully!" : "Workshop could not be scheduled.");
    } 
    else if (type == 2) {
        System.out.print("Enter meeting title: ");
        String title = input.nextLine();

        int id = readInt(input, "Enter student ID: ");
        input.nextLine();

        System.out.print("Enter meeting date and time (MM/DD/YYYY HH:MM): ");
        IDateTime start = DateTime.parse(input.nextLine());

        IDateTime end = addOneHour(start);

        System.out.print("Enter meeting location: ");
        String location = input.nextLine();

        boolean ok = system.scheduleMeeting(title, start, end, location, id);

        System.out.println(ok ? "Meeting scheduled successfully!" : "Meeting could not be scheduled.");
    } 
    else {
        System.out.println("Invalid type.");
    }
}  
    private static IDateTime addOneHour(IDateTime start) {
    int hour = start.getHour() + 1;
    int day = start.getDay();

    if (hour >= 24) {
        hour = 0;
        day++;
    }

    return new DateTime(start.getMonth(), day, start.getYear(), hour, start.getMinute());
}
    private static void printEventDetails(AdvisingSystem system, Scanner input) {
        System.out.println("1. By title");
        System.out.println("2. By student name");
        //System.out.println("3. Workshop students");
        int c = readInt(input, "Enter your choice: "); input.nextLine();
        if (c == 1) { System.out.print("Enter title: "); system.printEventDetailsByTitle(input.nextLine()); }
        else if (c == 2) { System.out.print("Enter student name: "); system.printEventDetailsByStudentName(input.nextLine()); }
        else {System.out.print("invalied input  ");
        // System.out.print("Enter workshop title: "); system.printWorkshopStudents(input.nextLine());
         }
    }

    private static void printStudents(AdvisingSystem system, Scanner input) {
        System.out.println("1. Exact name");
        System.out.println("2. Partial name");
        System.out.println("3. Major");
        System.out.println("4. Year level");
        int c = readInt(input, "Enter your choice: "); input.nextLine();
        if (c == 1) { System.out.print("Enter full name: "); system.printStudentsByName(input.nextLine()); }
        else if (c == 2) { System.out.print("Enter part of name: "); system.printStudentsByPartialName(input.nextLine()); }
        else if (c == 3) { System.out.print("Enter major: "); system.printStudentsByMajor(input.nextLine()); }
        else { int y = readInt(input, "Enter year level: "); input.nextLine(); system.printStudentsByYearLevel(y); }
    }

    private static void loadCSV(AdvisingSystem system, Scanner input) {
        System.out.print("Enter students CSV path: ");
        boolean s = system.loadStudentsFromCSV(input.nextLine());
        System.out.print("Enter events CSV path: ");
        boolean e = system.loadEventsFromCSV(input.nextLine());
        System.out.println("Students loaded: " + s + ", Events loaded: " + e);
        System.out.println("Student count: " + system.studentCount() + ", Event count: " + system.eventCount());
    }
}

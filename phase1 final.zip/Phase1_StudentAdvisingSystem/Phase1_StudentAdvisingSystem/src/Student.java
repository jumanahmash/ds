public class Student implements IStudent {
    private String name;
    private final int studentId;
    private String email;
    private String major;
    private int yearLevel;
    private String notes;
    private LinkedList<IEvent> schedule;

    public Student(String name, int studentId, String email, String major, int yearLevel, String notes) {
        this.name = name;
        this.studentId = studentId;
        this.email = email;
        this.major = major;
        this.yearLevel = yearLevel;
        this.notes = notes;
        this.schedule = new LinkedList<IEvent>();
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getStudentId() { return studentId; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }
    public int getYearLevel() { return yearLevel; }
    public void setYearLevel(int yearLevel) { this.yearLevel = yearLevel; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public LinkedList<IEvent> getSchedule() { return schedule; }

    public String getFirstName() {
        if (name == null) return "";
        int space = name.indexOf(' ');
        return space == -1 ? name : name.substring(0, space);
    }

    public int compareTo(IStudent other) {
        return this.studentId - other.getStudentId();
    }

    public String toString() {
        return "Name: " + name +
               "\nStudent ID: " + studentId +
               "\nEmail Address: " + email +
               "\nMajor: " + major +
               "\nYear Level: " + yearLevel +
               "\nNotes: " + notes;
    }
}

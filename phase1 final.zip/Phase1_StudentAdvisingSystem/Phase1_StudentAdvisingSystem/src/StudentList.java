public class StudentList implements IStudentList {
    private LinkedList<IStudent> students = new LinkedList<IStudent>();

    public boolean add(IStudent student) {
        if (student == null || findById(student.getStudentId()) != null) return false;
        int index = 0;
        while (index < students.size() && students.get(index).compareTo(student) < 0) index++;
        students.insertAt(index, student);
        return true;
    }

    public IStudent findById(int studentId) {
        for (int i = 0; i < students.size(); i++)
            if (students.get(i).getStudentId() == studentId) return students.get(i);
        return null;
    }

    public LinkedList<IStudent> findByName(String fullName) {
        LinkedList<IStudent> result = new LinkedList<IStudent>();
        for (int i = 0; i < students.size(); i++)
            if (students.get(i).getName().equalsIgnoreCase(fullName)) result.addLast(students.get(i));
        return result;
    }

    public LinkedList<IStudent> findByNameContains(String partialName) {
        LinkedList<IStudent> result = new LinkedList<IStudent>();
        String key = partialName.toLowerCase();
        for (int i = 0; i < students.size(); i++)
            if (students.get(i).getName().toLowerCase().contains(key)) result.addLast(students.get(i));
        return result;
    }

    public IStudent findByEmail(String email) {
        for (int i = 0; i < students.size(); i++)
            if (students.get(i).getEmail().equalsIgnoreCase(email)) return students.get(i);
        return null;
    }

    public LinkedList<IStudent> findByMajor(String major) {
        LinkedList<IStudent> result = new LinkedList<IStudent>();
        for (int i = 0; i < students.size(); i++)
            if (students.get(i).getMajor().equalsIgnoreCase(major)) result.addLast(students.get(i));
        return result;
    }

    public LinkedList<IStudent> findByYearLevel(int yearLevel) {
        LinkedList<IStudent> result = new LinkedList<IStudent>();
        for (int i = 0; i < students.size(); i++)
            if (students.get(i).getYearLevel() == yearLevel) result.addLast(students.get(i));
        return result;
    }

    public LinkedList<IStudent> getAll() { return students; }

    public boolean deleteById(int studentId) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getStudentId() == studentId) return students.removeAt(i);
        }
        return false;
    }

    public int size() { return students.size(); }
}

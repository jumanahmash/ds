public class Workshop extends Event implements IWorkshop {
    private LinkedList<IStudent> participants;

    public Workshop(String title, IDateTime startDateTime, IDateTime endDateTime, String location) {
        super(title, startDateTime, endDateTime, location);
        participants = new LinkedList<IStudent>();
    }

    public Workshop(int eventId, String title, IDateTime startDateTime, IDateTime endDateTime, String location) {
        super(eventId, title, startDateTime, endDateTime, location);
        participants = new LinkedList<IStudent>();
    }

    public LinkedList<IStudent> getParticipants() { return participants; }

    public boolean addParticipant(IStudent student) {
        if (student == null || hasStudent(student.getStudentId())) return false;
        participants.addLast(student);
        return true;
    }

    public boolean removeParticipantById(int studentId) {
        for (int i = 0; i < participants.size(); i++) {
            if (participants.get(i).getStudentId() == studentId) {
                participants.removeAt(i);
                return true;
            }
        }
        return false;
    }

    public boolean isEmpty() { return participants.isEmpty(); }

    public boolean hasStudent(int studentId) {
        for (int i = 0; i < participants.size(); i++) {
            if (participants.get(i).getStudentId() == studentId) return true;
        }
        return false;
    }

    public String toString() {
        String names = "";
        for (int i = 0; i < participants.size(); i++) {
            names += participants.get(i).getName();
            if (i < participants.size() - 1) names += ", ";
        }
        return "Workshop\n" + baseString() + "\nStudents: " + names;
    }
}
